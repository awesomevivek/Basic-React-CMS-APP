const dotenv = require("dotenv");
const mongoose = require('mongoose');
const express = require("express");
const cookieParser = require('cookie-parser');

const app = express();

app.use(cookieParser());

dotenv.config({path : './config.env'});
require('./db/conn');
app.use(express.json());
//const User = require('./model/userSchema'); 
app.use(require('./router/auth'));

const PORT = process.env.PORT;





//Middleware

// const middleware = (req, res, next) => {
//     console.log("Hello middlewalre");
//     next();
// }

//middleware();

// app.get('/', (req, res)=>{

//     res.send("Hello connect from server 111");

// });

// app.get('/about', middleware , (req, res)=>{

//     res.send("Hello connect from About");

// });

// app.get('/contact', (req, res)=>{

//     res.send("Hello connect from Contact");

// });

// app.get('/login', (req, res)=>{

//     res.send("Hello connect from login");

// });

// app.get('/register', (req, res)=>{

//     res.send("Hello connect from register");

// });

app.listen(PORT, ()=>{
    console.log("Server is running at http://localhost:5000");
})