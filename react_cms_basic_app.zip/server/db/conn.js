const mongoose = require("mongoose");

const DB = process.env.DATABASE;

//DB

//const DB = 'mongodb+srv://trimigha:Admin123@cluster0.yajsj.mongodb.net/TrimeghaDb?retryWrites=true&w=majority';

mongoose.connect(DB, {
  
useNewUrlParser: true, 

useUnifiedTopology: true
}).then(()=>{
    console.log("Connection Successful")
}).catch((err)=>console.log(err));

// const { MongoClient, ServerApiVersion } = require('mongodb');
// const uri = "mongodb+srv://trimigha:<password>@cluster0.yajsj.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
// const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true, serverApi: ServerApiVersion.v1 });
// client.connect(err => {
//   const collection = client.db("test").collection("devices");
//   // perform actions on the collection object
//   client.close();
// });




